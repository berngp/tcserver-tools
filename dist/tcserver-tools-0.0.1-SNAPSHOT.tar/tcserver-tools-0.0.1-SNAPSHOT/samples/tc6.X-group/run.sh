#!/bin/sh
../../bin/tcsgroup.sh . "$@"
