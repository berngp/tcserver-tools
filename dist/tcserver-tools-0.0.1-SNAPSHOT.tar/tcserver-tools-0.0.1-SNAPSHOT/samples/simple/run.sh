#!/bin/sh
../../bin/tcsmain.sh . start
