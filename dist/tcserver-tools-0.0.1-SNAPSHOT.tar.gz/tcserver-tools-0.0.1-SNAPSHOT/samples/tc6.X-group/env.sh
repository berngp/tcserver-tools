#!/bin/sh
#-------------------------------------------
if [ ! -d "$CATALINA_HOME" ]; then
       	export CATALINA_HOME="/opt/apache-tomcat/apache-tomcat-6.0.29"
fi
