#!/bin/sh
../../bin/tcsgroup . "$@"
