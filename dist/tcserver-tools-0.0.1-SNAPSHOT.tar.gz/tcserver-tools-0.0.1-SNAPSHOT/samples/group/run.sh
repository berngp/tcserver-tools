#!/bin/sh
../../bin/tcsgroup.sh . start
