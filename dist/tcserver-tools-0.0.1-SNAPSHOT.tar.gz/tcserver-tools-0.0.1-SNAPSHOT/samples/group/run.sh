#!/bin/sh
../../bin/tcsgroup . start
